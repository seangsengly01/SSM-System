package com.example.ssm_version_2;

import javafx.beans.property.*;

import java.time.LocalDateTime;

public class PaymentFeeTransaction {
    private final IntegerProperty id = new SimpleIntegerProperty();
    private final StringProperty paymentBank = new SimpleStringProperty();
    private final StringProperty accountNumber = new SimpleStringProperty();
    private final StringProperty accountName = new SimpleStringProperty();
    private final DoubleProperty amount = new SimpleDoubleProperty();
    private final StringProperty remark = new SimpleStringProperty();
    private final StringProperty status = new SimpleStringProperty();
    private final ObjectProperty<LocalDateTime> effectiveDate = new SimpleObjectProperty<>();
    private final ObjectProperty<LocalDateTime> createdDate = new SimpleObjectProperty<>();
    private final ObjectProperty<LocalDateTime> updatedDate = new SimpleObjectProperty<>();
    private final BooleanProperty finalized = new SimpleBooleanProperty();

    public PaymentFeeTransaction() {
    }

    public PaymentFeeTransaction(int id, String paymentBank, String accountNumber, String accountName, double amount, String status) {
        setId(id);
        setPaymentBank(paymentBank);
        setAccountNumber(accountNumber);
        setAccountName(accountName);
        setAmount(amount);
        setStatus(status);
    }

    public PaymentFeeTransaction(int id, String paymentBank, String accountNumber, String accountName, double amount, String remark, String status,
                                 LocalDateTime effectiveDate, LocalDateTime createdDate, LocalDateTime updatedDate, boolean finalized) {
        setId(id);
        setPaymentBank(paymentBank);
        setAccountNumber(accountNumber);
        setAccountName(accountName);
        setAmount(amount);
        setRemark(remark);
        setStatus(status);
        setEffectiveDate(effectiveDate);
        setCreatedDate(createdDate);
        setUpdatedDate(updatedDate);
        setFinalized(finalized);
    }

    public PaymentFeeTransaction(int id, String paymentBank, String accountNumber, String accountName, double amount, String status, String remark, LocalDateTime effectiveDate, LocalDateTime createdDate, LocalDateTime updatedDate) {
    }

    public int getId() {
        return id.get();
    }

    public IntegerProperty idProperty() {
        return id;
    }

    public void setId(int id) {
        this.id.set(id);
    }

    public String getPaymentBank() {
        return paymentBank.get();
    }

    public StringProperty paymentBankProperty() {
        return paymentBank;
    }

    public void setPaymentBank(String paymentBank) {
        this.paymentBank.set(paymentBank);
    }

    public String getAccountNumber() {
        return accountNumber.get();
    }

    public StringProperty accountNumberProperty() {
        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber.set(accountNumber);
    }

    public String getAccountName() {
        return accountName.get();
    }

    public StringProperty accountNameProperty() {
        return accountName;
    }

    public void setAccountName(String accountName) {
        this.accountName.set(accountName);
    }

    public double getAmount() {
        return amount.get();
    }

    public DoubleProperty amountProperty() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount.set(amount);
    }

    public String getRemark() {
        return remark.get();
    }

    public StringProperty remarkProperty() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark.set(remark);
    }

    public String getStatus() {
        return status.get();
    }

    public StringProperty statusProperty() {
        return status;
    }

    public void setStatus(String status) {
        this.status.set(status);
    }

    public LocalDateTime getEffectiveDate() {
        return effectiveDate.get();
    }

    public ObjectProperty<LocalDateTime> effectiveDateProperty() {
        return effectiveDate;
    }

    public void setEffectiveDate(LocalDateTime effectiveDate) {
        this.effectiveDate.set(effectiveDate);
    }

    public LocalDateTime getCreatedDate() {
        return createdDate.get();
    }

    public ObjectProperty<LocalDateTime> createdDateProperty() {
        return createdDate;
    }

    public void setCreatedDate(LocalDateTime createdDate) {
        this.createdDate.set(createdDate);
    }

    public LocalDateTime getUpdatedDate() {
        return updatedDate.get();
    }

    public ObjectProperty<LocalDateTime> updatedDateProperty() {
        return updatedDate;
    }

    public void setUpdatedDate(LocalDateTime updatedDate) {
        this.updatedDate.set(updatedDate);
    }

    public boolean isFinalized() {
        return finalized.get();
    }

    public BooleanProperty finalizedProperty() {
        return finalized;
    }

    public void setFinalized(boolean finalized) {
        this.finalized.set(finalized);
    }
}
