package com.example.ssm_version_2;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.effect.DropShadow;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

import java.sql.*;

public class LoginPage extends Application {

    private int userId;

    private Connection connectToDatabase() throws SQLException {
        String url = "jdbc:sqlserver://localhost:51828;databaseName=test001";
        String username = "sa";
        String password = "Demo@123";
        return DriverManager.getConnection(url, username, password);
    }

    private String getEmailFromLoggedInUser() {
        String email = "";
        try (Connection conn = connectToDatabase();
             PreparedStatement stmt = conn.prepareStatement("SELECT Email FROM Students WHERE ID = ?")) {
            stmt.setInt(1, userId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                email = rs.getString("Email");
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return email;
    }

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("SSM Login System");

        // Logo
        Image logoImage = new Image("file:C:/Users/seang/OneDrive/Desktop/rupp logo.png");
        ImageView logoImageView = new ImageView(logoImage);
        logoImageView.setFitHeight(100);
        logoImageView.setPreserveRatio(true);

        // Title
        Label titleLabel = new Label("Welcome Login to SSM System");
        titleLabel.setStyle("-fx-font-size: 18pt; -fx-font-weight: bold;");

        // Form fields
        TextField emailField = new TextField();
        emailField.setPromptText("Enter student email");

        PasswordField passwordField = new PasswordField();
        passwordField.setPromptText("Enter password");

        TextField studentIdField = new TextField();
        studentIdField.setPromptText("Enter student ID");

        // Error label for displaying login failure message
        Label errorLabel = new Label("");
        errorLabel.setTextFill(Color.RED);
        errorLabel.setAlignment(Pos.CENTER_LEFT);

        // Buttons
        Button loginButton = new Button("Login");
        Button registerButton = new Button("Register");

        // "Forget Password?" link
        Label forgetPasswordLabel = new Label("Forget Password?");
        forgetPasswordLabel.setStyle("-fx-text-fill: blue; -fx-underline: true;");
        // Add a mouse click event handler to the label
        forgetPasswordLabel.setOnMouseClicked(event -> {
            // Navigate to the ForgetPasswordPage
            ForgetPasswordPage forgetPasswordPage = new ForgetPasswordPage();
            // Replace the current scene with the ForgetPasswordPage
            try {
                forgetPasswordPage.start(primaryStage);
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });
        // Set action for the register button to switch to RegistrationPage
        registerButton.setOnAction(e -> {
            RegistrationPage registrationPage = new RegistrationPage();
            try {
                registrationPage.start(primaryStage);
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });

        // Set action for the login button
        loginButton.setOnAction(e -> {
            String email = emailField.getText();
            String password = passwordField.getText();
            String studentId = studentIdField.getText();

            // Validate fields
            if (email.trim().isEmpty() || password.trim().isEmpty() || studentId.trim().isEmpty()) {
                errorLabel.setText("Fields cannot be blank.");
                return;
            }

            try (Connection conn = connectToDatabase();
                 PreparedStatement stmt = conn.prepareStatement("SELECT * FROM Students WHERE Email = ? AND Password = ? AND StudentID = ?")) {
                stmt.setString(1, email);
                stmt.setString(2, password);
                stmt.setString(3, studentId);
                ResultSet rs = stmt.executeQuery();
                if (rs.next()) {
                    userId = rs.getInt("ID");
                    System.out.println("Login successful");
                    String loggedInUserEmail = rs.getString("Email");
                    primaryStage.setFullScreen(true);

                    // Create DashboardPage instance and show the dashboard
                    DashboardPage dashboardPage = new DashboardPage();
                    dashboardPage.showDashboard(primaryStage, loggedInUserEmail);
                } else {
                    errorLabel.setText("Login failed. Incorrect email, password, or student ID.");
                }

            } catch (SQLException ex) {
                ex.printStackTrace();
                errorLabel.setText("An error occurred. Please try again.");

            }
        });

        // Layout setup
        GridPane gridPane = new GridPane();
        gridPane.setAlignment(Pos.CENTER);
        gridPane.setHgap(10);
        gridPane.setVgap(10);
        gridPane.setPadding(new Insets(10, 10, 10, 10));

        gridPane.add(new Label("Student Email:"), 0, 0);
        gridPane.add(emailField, 1, 0);
        gridPane.add(new Label("Student ID:"), 0, 1);
        gridPane.add(studentIdField, 1, 1);
        gridPane.add(new Label("Password:"), 0, 2);
        gridPane.add(passwordField, 1, 2);

        gridPane.add(errorLabel, 0, 3, 2, 1); // Add error label below fields

        // Spacer
        Region spacer = new Region();
        spacer.setPrefHeight(20);
        gridPane.add(spacer, 0, 4, 2, 1);

        HBox buttonsBox = new HBox(10);
        buttonsBox.setAlignment(Pos.CENTER);
        buttonsBox.getChildren().addAll(registerButton, loginButton);

        VBox formBox = new VBox(20);
        formBox.setMaxWidth(550);
        formBox.setAlignment(Pos.CENTER);
        formBox.getChildren().addAll(titleLabel, gridPane, forgetPasswordLabel, buttonsBox);
        formBox.setPadding(new Insets(20));
        formBox.setStyle("-fx-background-color: white; -fx-border-radius: 10; -fx-background-radius: 10;");

        // Add shadow effect to formBox
        DropShadow shadow = new DropShadow();
        shadow.setRadius(10.0);
        shadow.setOffsetX(5.0);
        shadow.setOffsetY(5.0);
        shadow.setColor(Color.color(0.4, 0.5, 0.5));
        formBox.setEffect(shadow);

        VBox vbox = new VBox(20);
        vbox.setAlignment(Pos.CENTER);
        vbox.getChildren().addAll(logoImageView, formBox);
        vbox.setPadding(new Insets(20));

        // Set background image
        StackPane root = new StackPane();
        root.setStyle("-fx-background-image: url('file:C:/Users/seang/OneDrive/Desktop/rupp logo.png'); " +
                "-fx-background-size: cover; " +
                "-fx-background-position: center center; " +
                "-fx-background-repeat: no-repeat;");

        root.getChildren().add(vbox);

        Scene scene = new Scene(root);
        primaryStage.setScene(scene);
        primaryStage.setFullScreen(true);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
