package com.example.ssm_version_2;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;

public class AddUserForm extends VBox {

    private TextField emailField;
    private TextField studentIDField;
    private TextField passwordField;
    private TextField firstNameField;
    private TextField lastNameField;
    private TextField phoneNumberField;
    private TextField departmentField;
    private TextField birthdayField;
    private TextField joinDateField;

    public AddUserForm() {
        setupForm();
    }

    private void setupForm() {
        Label titleLabel = new Label("Add New User");
        titleLabel.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;");

        emailField = new TextField();
        emailField.setPromptText("Email");

        studentIDField = new TextField();
        studentIDField.setPromptText("Student ID");

        passwordField = new TextField();
        passwordField.setPromptText("Password");

        firstNameField = new TextField();
        firstNameField.setPromptText("First Name");

        lastNameField = new TextField();
        lastNameField.setPromptText("Last Name");

        phoneNumberField = new TextField();
        phoneNumberField.setPromptText("Phone Number");

        departmentField = new TextField();
        departmentField.setPromptText("Department");

        birthdayField = new TextField();
        birthdayField.setPromptText("Birthday (YYYY-MM-DD)");

        joinDateField = new TextField();
        joinDateField.setPromptText("Join Date (YYYY-MM-DD)");

        Button addUserButton = new Button("Add User");
        addUserButton.setOnAction(e -> addUser());

        GridPane gridPane = new GridPane();
        gridPane.setHgap(10);
        gridPane.setVgap(10);
        gridPane.addRow(0, new Label("Email:"), emailField);
        gridPane.addRow(1, new Label("Student ID:"), studentIDField);
        gridPane.addRow(2, new Label("Password:"), passwordField);
        gridPane.addRow(3, new Label("First Name:"), firstNameField);
        gridPane.addRow(4, new Label("Last Name:"), lastNameField);
        gridPane.addRow(5, new Label("Phone Number:"), phoneNumberField);
        gridPane.addRow(6, new Label("Department:"), departmentField);
        gridPane.addRow(7, new Label("Birthday:"), birthdayField);
        gridPane.addRow(8, new Label("Join Date:"), joinDateField);
        gridPane.addRow(9, addUserButton);

        this.getChildren().addAll(titleLabel, gridPane);
    }

    private void addUser() {
        String email = emailField.getText().trim();
        String studentID = studentIDField.getText().trim();
        String password = passwordField.getText().trim();
        String firstName = firstNameField.getText().trim();
        String lastName = lastNameField.getText().trim();
        String phoneNumber = phoneNumberField.getText().trim();
        String department = departmentField.getText().trim();
        String birthdayText = birthdayField.getText().trim();
        String joinDateText = joinDateField.getText().trim();

        if (email.isEmpty() || studentID.isEmpty() || password.isEmpty() || firstName.isEmpty() || lastName.isEmpty() ||
                phoneNumber.isEmpty() || department.isEmpty() || birthdayText.isEmpty() || joinDateText.isEmpty()) {
            showAlert("Error", "Please fill in all fields.");
            return;
        }

        LocalDate birthday;
        LocalDate joinDate;

        try {
            birthday = LocalDate.parse(birthdayText);
        } catch (DateTimeParseException e) {
            showAlert("Error", "Invalid birthday format. Please use YYYY-MM-DD.");
            return;
        }

        try {
            joinDate = LocalDate.parse(joinDateText);
        } catch (DateTimeParseException e) {
            showAlert("Error", "Invalid join date format. Please use YYYY-MM-DD.");
            return;
        }

        if (birthday.isAfter(LocalDate.now())) {
            showAlert("Error", "Birthday cannot be in the future.");
            return;
        }

        if (joinDate.isAfter(LocalDate.now())) {
            showAlert("Error", "Join date cannot be in the future.");
            return;
        }

        String insertQuery = "INSERT INTO [test001].[dbo].[Students] " +
                "([Email], [StudentID], [Password], [FirstName], [LastName], [PhoneNumber], [Department], [Birthday], [JoinDate]) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = DriverManager.getConnection(LoginPageAdmin.DB_URL, LoginPageAdmin.DB_USER, LoginPageAdmin.DB_PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(insertQuery)) {

            pstmt.setString(1, email);
            pstmt.setString(2, studentID);
            pstmt.setString(3, password);
            pstmt.setString(4, firstName);
            pstmt.setString(5, lastName);
            pstmt.setString(6, phoneNumber);
            pstmt.setString(7, department);
            pstmt.setDate(8, java.sql.Date.valueOf(birthday));
            pstmt.setDate(9, java.sql.Date.valueOf(joinDate));

            pstmt.executeUpdate();
            showAlert("Success", "New user has been added successfully.");

            // Clear fields after successful addition
            emailField.clear();
            studentIDField.clear();
            passwordField.clear();
            firstNameField.clear();
            lastNameField.clear();
            phoneNumberField.clear();
            departmentField.clear();
            birthdayField.clear();
            joinDateField.clear();

        } catch (SQLException e) {
            showAlert("Error", "An error occurred while adding the user.");
            e.printStackTrace();
        }
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
