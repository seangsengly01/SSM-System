package com.example.ssm_version_2;

import javafx.application.Application;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

import java.sql.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Optional;

public class AdminDashboard extends Application {

    static final String DB_URL = "jdbc:sqlserver://localhost:51828;databaseName=test001";
    static final String DB_USER = "sa";
    static final String DB_PASSWORD = "Demo@123";

    private TableView<Student> tableView;
    private FilteredList<Student> filteredData;
    private TextField searchField;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Admin Dashboard");

        // Logo
        Image logoImage = new Image("file:C:/Users/seang/OneDrive/Desktop/rupp logo.png");
        ImageView logoImageView = new ImageView(logoImage);
        logoImageView.setFitWidth(100);
        logoImageView.setPreserveRatio(true);
        logoImageView.setEffect(new javafx.scene.effect.DropShadow(10, Color.GRAY));

        // Welcome message
        Label welcomeLabel = new Label("Welcome to Admin Dashboard");
        welcomeLabel.setStyle("-fx-font-size: 24px; -fx-font-weight: bold;");

        HBox headerBox = new HBox(10, logoImageView, welcomeLabel);
        headerBox.setAlignment(Pos.CENTER_LEFT);
        headerBox.setPadding(new Insets(10));

        // Search bar
        searchField = new TextField();
        searchField.setPromptText("Search by phone number, student ID, or email");
        Button searchButton = new Button("Search");
        searchButton.setOnAction(e -> filterData());

        HBox searchBox = new HBox(10, searchField, searchButton);
        searchBox.setAlignment(Pos.CENTER_LEFT);
        searchBox.setPadding(new Insets(10));

        tableView = new TableView<>();
        setupTableView();

        // Add user form
        VBox addUserForm = setupAddUserForm();

        VBox vbox = new VBox(10, headerBox, searchBox, tableView, addUserForm);
        vbox.setPadding(new Insets(10));

        Scene scene = new Scene(vbox);
        primaryStage.setScene(scene);

        // Set the stage to full screen mode
        primaryStage.setFullScreen(true);
        primaryStage.show();

        loadDataFromDatabase();
    }

    private void setupTableView() {
        TableColumn<Student, String> noColumn = new TableColumn<>("No");
        noColumn.setCellValueFactory(cellData -> {
            int rowIndex = tableView.getItems().indexOf(cellData.getValue()) + 1;
            return new SimpleStringProperty(String.valueOf(rowIndex));
        });

        TableColumn<Student, String> emailColumn = new TableColumn<>("Email");
        emailColumn.setCellValueFactory(new PropertyValueFactory<>("email"));

        TableColumn<Student, String> studentIDColumn = new TableColumn<>("Student ID");
        studentIDColumn.setCellValueFactory(new PropertyValueFactory<>("studentID"));

        TableColumn<Student, String> passwordColumn = new TableColumn<>("Password");
        passwordColumn.setCellValueFactory(new PropertyValueFactory<>("password"));

        TableColumn<Student, String> firstNameColumn = new TableColumn<>("First Name");
        firstNameColumn.setCellValueFactory(new PropertyValueFactory<>("firstName"));

        TableColumn<Student, String> lastNameColumn = new TableColumn<>("Last Name");
        lastNameColumn.setCellValueFactory(new PropertyValueFactory<>("lastName"));

        TableColumn<Student, String> phoneNumberColumn = new TableColumn<>("Phone Number");
        phoneNumberColumn.setCellValueFactory(new PropertyValueFactory<>("phoneNumber"));

        TableColumn<Student, String> departmentColumn = new TableColumn<>("Department");
        departmentColumn.setCellValueFactory(new PropertyValueFactory<>("department"));

        TableColumn<Student, String> birthdayColumn = new TableColumn<>("Birthday");
        birthdayColumn.setCellValueFactory(new PropertyValueFactory<>("birthday"));

        TableColumn<Student, String> joinDateColumn = new TableColumn<>("Join Date");
        joinDateColumn.setCellValueFactory(new PropertyValueFactory<>("joinDate"));

        TableColumn<Student, Void> actionColumn = new TableColumn<>("Actions");
        actionColumn.setCellFactory(param -> new TableCell<>() {
            private final Button editButton = new Button("Edit");
            private final Button deleteButton = new Button("Delete");

            {
                editButton.setOnAction(event -> {
                    Student student = getTableView().getItems().get(getIndex());
                    showEditUserDialog(student);
                });

                deleteButton.setOnAction(event -> {
                    Student student = getTableView().getItems().get(getIndex());
                    showDeleteConfirmationDialog(student);
                });
            }

            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                if (empty) {
                    setGraphic(null);
                } else {
                    HBox buttons = new HBox(editButton, deleteButton);
                    buttons.setSpacing(5);
                    setGraphic(buttons);
                }
            }
        });

        tableView.getColumns().addAll(noColumn, emailColumn, studentIDColumn, passwordColumn, firstNameColumn, lastNameColumn,
                phoneNumberColumn, departmentColumn, birthdayColumn, joinDateColumn, actionColumn);
        tableView.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
    }

    private void loadDataFromDatabase() {
        ObservableList<Student> data = FXCollections.observableArrayList();

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT [Email], [StudentID], [Password], [FirstName], [LastName], " +
                     "[PhoneNumber], [Department], [Birthday], [JoinDate] FROM [test001].[dbo].[Students] ORDER BY ID Desc")) {

            while (rs.next()) {
                data.add(new Student(
                        rs.getString("Email"),
                        rs.getString("StudentID"),
                        rs.getString("Password"),
                        rs.getString("FirstName"),
                        rs.getString("LastName"),
                        rs.getString("PhoneNumber"),
                        rs.getString("Department"),
                        rs.getString("Birthday"),
                        rs.getString("JoinDate")
                ));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        filteredData = new FilteredList<>(data, p -> true);
        tableView.setItems(filteredData);
    }

    private void filterData() {
        String searchText = searchField.getText().toLowerCase();
        filteredData.setPredicate(student -> {
            if (searchText == null || searchText.isEmpty()) {
                return true;
            }
            return student.getEmail().toLowerCase().contains(searchText) ||
                    student.getStudentID().toLowerCase().contains(searchText) ||
                    student.getPhoneNumber().toLowerCase().contains(searchText);
        });
    }

    private VBox setupAddUserForm() {
        // Form fields
        TextField emailField = new TextField();
        emailField.setPromptText("Email");
        TextField studentIDField = new TextField();
        studentIDField.setPromptText("Student ID");
        TextField firstNameField = new TextField();
        firstNameField.setPromptText("First Name");
        TextField lastNameField = new TextField();
        lastNameField.setPromptText("Last Name");
        TextField phoneNumberField = new TextField();
        phoneNumberField.setPromptText("Phone Number");
        TextField departmentField = new TextField();
        departmentField.setPromptText("Department");
        // Use DatePicker for Birthday and Join Date fields
        DatePicker birthdayPicker = new DatePicker();
        birthdayPicker.setPromptText("Birthday (YYYY-MM-DD)");
        DatePicker joinDatePicker = new DatePicker();
        joinDatePicker.setPromptText("Join Date (YYYY-MM-DD)");
        PasswordField passwordField = new PasswordField();
        passwordField.setPromptText("Password");

        // Add user button
        Button addUserButton = new Button("Add User");
        addUserButton.setStyle("-fx-background-color: #4CAF50; -fx-text-fill: white; -fx-font-weight: bold;");
        addUserButton.setOnAction(e -> addUser(emailField.getText(), studentIDField.getText(), passwordField.getText(),
                firstNameField.getText(), lastNameField.getText(), phoneNumberField.getText(),
                departmentField.getText(), birthdayPicker.getValue().toString(), joinDatePicker.getValue().toString()));

        // Form layout
        GridPane gridPane = new GridPane();
        gridPane.setHgap(10);
        gridPane.setVgap(5);

        // Add labels and fields to the gridPane
        int row = 0;
        gridPane.addRow(row++, new Label("Email:"), emailField, new Label("Student ID:"), studentIDField);
        gridPane.addRow(row++, new Label("First Name:"), firstNameField, new Label("Last Name:"), lastNameField);
        gridPane.addRow(row++, new Label("Phone Number:"), phoneNumberField, new Label("Department:"), departmentField);
        gridPane.addRow(row++, new Label("Birthday:"), birthdayPicker, new Label("Join Date:"), joinDatePicker);
        gridPane.addRow(row++, new Label("Password:"), passwordField);

        // Set column constraints to make labels take up 30% width and fields take up 70% width
        ColumnConstraints labelCol = new ColumnConstraints();
        labelCol.setPercentWidth(30);
        ColumnConstraints fieldCol = new ColumnConstraints();
        fieldCol.setPercentWidth(70);
        gridPane.getColumnConstraints().addAll(labelCol, fieldCol, labelCol, fieldCol);

        // Wrap the GridPane and button in a VBox
        VBox vbox = new VBox(10);
        vbox.getChildren().addAll(new Label("Add New User: "), gridPane, addUserButton);
        vbox.setPadding(new Insets(10));
        vbox.setAlignment(Pos.CENTER_LEFT);

        return vbox;
    }



    private void addUser(String email, String studentID, String password, String firstName, String lastName, String phoneNumber,
                         String department, String birthday, String joinDate) {
        if (email.isEmpty() || studentID.isEmpty() || password.isEmpty() || firstName.isEmpty() ||
                lastName.isEmpty() || phoneNumber.isEmpty() || department.isEmpty() || birthday.isEmpty() || joinDate.isEmpty()) {
            showAlert("Error", "All fields are required.");
            return;
        }

        // Validate Email
        if (!email.matches("^[\\w.-]+@rupp\\.edu\\.kh$")) {
            showAlert("Error", "Invalid email format. Email must end with @rupp.edu.kh");
            return;
        }

        // Validate Phone Number and Student ID
        if (!phoneNumber.matches("\\d+") || !studentID.matches("\\d+")) {
            showAlert("Error", "Phone number and student ID must contain only digits.");
            return;
        }

        // Validate Join Date and Birthday
        if (!isValidDate(birthday) || !isValidDate(joinDate)) {
            showAlert("Error", "Invalid date format or date cannot be in the future.");
            return;
        }

        // Add additional input validation logic here

        Alert confirmationAlert = new Alert(Alert.AlertType.CONFIRMATION);
        confirmationAlert.setTitle("Confirmation");
        confirmationAlert.setHeaderText("Confirm Adding User");
        confirmationAlert.setContentText("Are you sure you want to add this user?");

        Optional<ButtonType> result = confirmationAlert.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            String insertQuery = "INSERT INTO [test001].[dbo].[Students] " +
                    "([Email], [StudentID], [Password], [FirstName], [LastName], [PhoneNumber], [Department], [Birthday], [JoinDate]) " +
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

            try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
                 PreparedStatement pstmt = conn.prepareStatement(insertQuery)) {

                pstmt.setString(1, email);
                pstmt.setString(2, studentID);
                pstmt.setString(3, password);
                pstmt.setString(4, firstName);
                pstmt.setString(5, lastName);
                pstmt.setString(6, phoneNumber);
                pstmt.setString(7, department);

                // Convert string dates to java.sql.Date
                pstmt.setDate(8, java.sql.Date.valueOf(birthday));
                pstmt.setDate(9, java.sql.Date.valueOf(joinDate));

                pstmt.executeUpdate();
                showAlert("User Added", "New user has been added successfully.");
                loadDataFromDatabase();

            } catch (SQLException e) {
                e.printStackTrace();
                showAlert("Error", "An error occurred while adding the user.");
            }
        }
    }

    private boolean isValidDate(String date) {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            sdf.setLenient(false); // Disable leniency
            sdf.parse(date); // This will throw a ParseException if the date is invalid
            return true;
        } catch (ParseException e) {
            return false;
        }
    }

    private void showDeleteConfirmationDialog(Student student) {
        Alert confirmationAlert = new Alert(Alert.AlertType.CONFIRMATION);
        confirmationAlert.setTitle("Confirmation");
        confirmationAlert.setHeaderText("Confirm Deleting User");
        confirmationAlert.setContentText("Are you sure you want to delete this user?");

        Optional<ButtonType> result = confirmationAlert.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            deleteUser(student);
        }
    }

    private void deleteUser(Student student) {
        String deleteQuery = "DELETE FROM [test001].[dbo].[Students] WHERE [StudentID] = ?";

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(deleteQuery)) {

            pstmt.setString(1, student.getStudentID());
            pstmt.executeUpdate();
            showAlert("User Deleted", "User has been deleted successfully.");
            loadDataFromDatabase();

        } catch (Exception e) {
            e.printStackTrace();
            showAlert("Error", "An error occurred while deleting the user.");
        }
    }


    private void showEditUserDialog(Student student) {
        // Edit user form
        Dialog<ButtonType> dialog = new Dialog<>();
        dialog.setTitle("Edit User");

        TextField emailField = new TextField(student.getEmail());
        TextField studentIDField = new TextField(student.getStudentID());
        PasswordField passwordField = new PasswordField();
        passwordField.setText(student.getPassword());
        TextField firstNameField = new TextField(student.getFirstName());
        TextField lastNameField = new TextField(student.getLastName());
        TextField phoneNumberField = new TextField(student.getPhoneNumber());
        TextField departmentField = new TextField(student.getDepartment());
        TextField birthdayField = new TextField(student.getBirthday());
        TextField joinDateField = new TextField(student.getJoinDate());

        GridPane gridPane = new GridPane();
        gridPane.setPadding(new Insets(10));
        gridPane.setHgap(10);
        gridPane.setVgap(10);
        gridPane.add(new Label("Email:"), 0, 0);
        gridPane.add(emailField, 1, 0);
        gridPane.add(new Label("Student ID:"), 0, 1);
        gridPane.add(studentIDField, 1, 1);
        gridPane.add(new Label("Password:"), 0, 2);
        gridPane.add(passwordField, 1, 2);
        gridPane.add(new Label("First Name:"), 0, 3);
        gridPane.add(firstNameField, 1, 3);
        gridPane.add(new Label("Last Name:"), 0, 4);
        gridPane.add(lastNameField, 1, 4);
        gridPane.add(new Label("Phone Number:"), 0, 5);
        gridPane.add(phoneNumberField, 1, 5);
        gridPane.add(new Label("Department:"), 0, 6);
        gridPane.add(departmentField, 1, 6);
        gridPane.add(new Label("Birthday:"), 0, 7);
        gridPane.add(birthdayField, 1, 7);
        gridPane.add(new Label("Join Date:"), 0, 8);
        gridPane.add(joinDateField, 1, 8);

        dialog.getDialogPane().setContent(gridPane);
        dialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);

        dialog.showAndWait().ifPresent(response -> {
            if (response == ButtonType.OK) {
                updateUser(student, emailField.getText(), studentIDField.getText(), passwordField.getText(),
                        firstNameField.getText(), lastNameField.getText(), phoneNumberField.getText(),
                        departmentField.getText(), birthdayField.getText(), joinDateField.getText());
            }
        });
    }

    private void updateUser(Student student, String email, String studentID, String password, String firstName,
                            String lastName, String phoneNumber, String department, String birthday, String joinDate) {
        String updateQuery = "UPDATE [test001].[dbo].[Students] SET " +
                "[Email] = ?, [Password] = ?, [FirstName] = ?, [LastName] = ?, [PhoneNumber] = ?, " +
                "[Department] = ?, [Birthday] = ?, [JoinDate] = ? WHERE [StudentID] = ?";

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(updateQuery)) {

            pstmt.setString(1, email);
            pstmt.setString(2, password);
            pstmt.setString(3, firstName);
            pstmt.setString(4, lastName);
            pstmt.setString(5, phoneNumber);
            pstmt.setString(6, department);
            pstmt.setString(7, birthday);
            pstmt.setString(8, joinDate);
            pstmt.setString(9, studentID);

            int rowsUpdated = pstmt.executeUpdate();
            if (rowsUpdated > 0) {
                // Update the existing Student object with the new data
                student.setEmail(email);
                student.setFirstName(firstName);
                student.setLastName(lastName);
                student.setPhoneNumber(phoneNumber);
                student.setDepartment(department);
                student.setBirthday(birthday);
                student.setJoinDate(joinDate);

                showAlert("User Updated", "User has been updated successfully.");
            } else {
                showAlert("Error", "Failed to update user. No matching record found.");
            }

        } catch (Exception e) {
            e.printStackTrace();
            showAlert("Error", "An error occurred while updating the user.");
        }
    }


    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    public static class Student {
        private final SimpleStringProperty email;
        private final SimpleStringProperty studentID;
        private final SimpleStringProperty password;
        private final SimpleStringProperty firstName;
        private final SimpleStringProperty lastName;
        private final SimpleStringProperty phoneNumber;
        private final SimpleStringProperty department;
        private final SimpleStringProperty birthday;
        private final SimpleStringProperty joinDate;

        public Student(String email, String studentID, String password, String firstName, String lastName,
                       String phoneNumber, String department, String birthday, String joinDate) {
            this.email = new SimpleStringProperty(email);
            this.studentID = new SimpleStringProperty(studentID);
            this.password = new SimpleStringProperty(password);
            this.firstName = new SimpleStringProperty(firstName);
            this.lastName = new SimpleStringProperty(lastName);
            this.phoneNumber = new SimpleStringProperty(phoneNumber);
            this.department = new SimpleStringProperty(department);
            this.birthday = new SimpleStringProperty(birthday);
            this.joinDate = new SimpleStringProperty(joinDate);
        }

        public String getEmail() {
            return email.get();
        }

        public void setEmail(String email) {
            this.email.set(email);
        }


        public String getStudentID() {
            return studentID.get();
        }

        public String getPassword() {
            return password.get();
        }

        public String getFirstName() {
            return firstName.get();
        }

        public void setFirstName(String firstName) {
            this.firstName.set(firstName);
        }

        public String getLastName() {
            return lastName.get();
        }

        public void setLastName(String lastName) {
            this.lastName.set(lastName);
        }

        public String getPhoneNumber() {
            return phoneNumber.get();
        }

        public void setPhoneNumber(String phoneNumber) {
            this.phoneNumber.set(phoneNumber);
        }

        public String getDepartment() {
            return department.get();
        }

        public void setDepartment(String department) {
            this.department.set(department);
        }

        public String getBirthday() {
            return birthday.get();
        }

        public void setBirthday(String birthday) {
            this.birthday.set(birthday);
        }

        public String getJoinDate() {
            return joinDate.get();
        }

        public void setJoinDate(String joinDate) {
            this.joinDate.set(joinDate);
        }
    }
}

