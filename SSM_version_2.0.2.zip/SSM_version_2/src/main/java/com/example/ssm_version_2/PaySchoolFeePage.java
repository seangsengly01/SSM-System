package com.example.ssm_version_2;

import com.microsoft.sqlserver.jdbc.SQLServerException;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.font.PDFont;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.apache.pdfbox.pdmodel.graphics.image.PDImageXObject;

public class PaySchoolFeePage {

    private Stage primaryStage;
    private TableView<PaymentFeeTransaction> tableView;
    private FilteredList<PaymentFeeTransaction> filteredData;

    public void showPaySchoolFee(Stage primaryStage, String userEmail) {
        this.primaryStage = primaryStage;

        primaryStage.setTitle("Pay School Fee");

        // Create TableView
        tableView = new TableView<>();
        tableView.setPrefSize(800, 500);

        // Define columns
        TableColumn<PaymentFeeTransaction, Integer> idColumn = new TableColumn<>("ID");
        idColumn.setCellValueFactory(new PropertyValueFactory<>("id"));

        TableColumn<PaymentFeeTransaction, String> paymentBankColumn = new TableColumn<>("Payment Bank");
        paymentBankColumn.setCellValueFactory(new PropertyValueFactory<>("paymentBank"));

        TableColumn<PaymentFeeTransaction, String> accountNumberColumn = new TableColumn<>("Account Number");
        accountNumberColumn.setCellValueFactory(new PropertyValueFactory<>("accountNumber"));

        TableColumn<PaymentFeeTransaction, String> accountNameColumn = new TableColumn<>("Account Name");
        accountNameColumn.setCellValueFactory(new PropertyValueFactory<>("accountName"));

        TableColumn<PaymentFeeTransaction, Double> amountColumn = new TableColumn<>("Amount");
        amountColumn.setCellValueFactory(new PropertyValueFactory<>("amount"));

        TableColumn<PaymentFeeTransaction, String> statusColumn = new TableColumn<>("Status");
        statusColumn.setCellValueFactory(new PropertyValueFactory<>("status"));

        TableColumn<PaymentFeeTransaction, Void> actionColumn = new TableColumn<>("Actions");
        actionColumn.setCellFactory(param -> new TableCell<>() {
            private final Button cancelButton = new Button("Cancel");
            private final Button sendButton = new Button("Send");
            private final MenuButton actionsMenu = new MenuButton("Actions");
            private final MenuItem viewDetailItem = new MenuItem("View Detail");
            private final MenuItem exportPdfItem = new MenuItem("Export PDF");

            {
                cancelButton.setOnAction(e -> {
                    PaymentFeeTransaction transaction = getTableView().getItems().get(getIndex());
                    showConfirmationDialog(transaction, "Yes", "Are you sure you want to cancel this transaction?", "Cancelled");
                });
                sendButton.setOnAction(e -> {
                    PaymentFeeTransaction transaction = getTableView().getItems().get(getIndex());
                    showConfirmationDialog(transaction, "Yes", "Are you sure you want to send this transaction?", "Sent");
                });
                viewDetailItem.setOnAction(e -> {
                    PaymentFeeTransaction transaction = getTableView().getItems().get(getIndex());
                    showTransactionDetails(transaction);
                });
                exportPdfItem.setOnAction(e -> {
                    PaymentFeeTransaction transaction = getTableView().getItems().get(getIndex());
                    try {
                        exportTransactionToPDF(transaction);
                    } catch (IOException ex) {
                        throw new RuntimeException(ex);
                    }
                });

                actionsMenu.getItems().addAll(viewDetailItem, exportPdfItem);
                HBox actionButtons = new HBox(10, actionsMenu, cancelButton, sendButton);
                setGraphic(actionButtons);
                setContentDisplay(ContentDisplay.GRAPHIC_ONLY);
            }

            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                if (empty) {
                    setGraphic(null);
                } else {
                    PaymentFeeTransaction transaction = getTableView().getItems().get(getIndex());
                    if ("Cancelled".equals(transaction.getStatus()) || "Sent".equals(transaction.getStatus())) {
                        setGraphic(actionsMenu);
                    } else {
                        setGraphic(new HBox(10, cancelButton, sendButton));
                    }
                    setContentDisplay(ContentDisplay.GRAPHIC_ONLY);
                }
            }
        });


        tableView.getColumns().addAll(idColumn, paymentBankColumn, accountNumberColumn, accountNameColumn,
                amountColumn, statusColumn, actionColumn);

        // Fetch and populate data from the database for the given user
        ObservableList<PaymentFeeTransaction> transactions = FXCollections.observableArrayList();
        fetchTransactionsForUserFromDatabase(transactions, userEmail);

        // Set up filtered data
        filteredData = new FilteredList<>(transactions, p -> true);
        tableView.setItems(filteredData);

        // Search bar
        TextField searchField = new TextField();
        searchField.setPromptText("Search");
        searchField.textProperty().addListener((observable, oldValue, newValue) -> {
            filteredData.setPredicate(transaction -> {
                if (newValue == null || newValue.isEmpty()) {
                    return true;
                }
                String lowerCaseFilter = newValue.toLowerCase();
                if (transaction.getPaymentBank().toLowerCase().contains(lowerCaseFilter)) {
                    return true;
                } else if (transaction.getAccountNumber().toLowerCase().contains(lowerCaseFilter)) {
                    return true;
                } else if (transaction.getAccountName().toLowerCase().contains(lowerCaseFilter)) {
                    return true;
                } else if (transaction.getStatus().toLowerCase().contains(lowerCaseFilter)) {
                    return true;
                } else if (String.valueOf(transaction.getAmount()).contains(lowerCaseFilter)) {
                    return true;
                }
                return false; // Does not match
            });
        });

        // Back Button
        Button backButton = new Button("Back");
        backButton.setStyle("-fx-background-color: #4CAF50; -fx-text-fill: white; -fx-padding: 10px 20px;");
        backButton.setOnAction(e -> {
            primaryStage.close();
            DashboardPage dashboardPage = new DashboardPage();
            try {
                dashboardPage.showDashboard(primaryStage, userEmail);
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });

        // Logo and Welcome Title
        Label welcomeLabel = new Label("Welcome, " + userEmail);
        welcomeLabel.setStyle("-fx-font-size: 20px; -fx-font-weight: bold;");
        ImageView logoImageView = new ImageView(new Image("file:C:/Users/seang/OneDrive/Desktop/rupp logo.png"));
        logoImageView.setFitHeight(100);
        logoImageView.setPreserveRatio(true);
        VBox headerBox = new VBox(10, logoImageView, welcomeLabel);
        headerBox.setAlignment(Pos.CENTER);
        headerBox.setPadding(new Insets(20));

        // Search Box
        HBox searchBox = new HBox(10, new Label("Search:"), searchField);
        searchBox.setAlignment(Pos.CENTER);

        // Layout
        BorderPane layout = new BorderPane();
        layout.setTop(new VBox(headerBox, searchBox));
        layout.setCenter(tableView);
        layout.setBottom(backButton);
        BorderPane.setAlignment(backButton, Pos.CENTER);
        BorderPane.setMargin(backButton, new Insets(20));

        // Scene
        Scene scene = new Scene(layout, 1024, 768);
        primaryStage.setScene(scene);
        primaryStage.setFullScreen(true);
        primaryStage.show();
    }

    private void showConfirmationDialog(PaymentFeeTransaction transaction, String action, String message, String status) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle(action + " Transaction");
        alert.setHeaderText(null);
        alert.setContentText(message);

        ButtonType confirmButton = new ButtonType(action);
        ButtonType cancelButton = new ButtonType("Cancel", ButtonBar.ButtonData.CANCEL_CLOSE);

        alert.getButtonTypes().setAll(confirmButton, cancelButton);

        alert.showAndWait().ifPresent(type -> {
            if (type == confirmButton) {
                updateTransactionStatus(transaction, status);
            }
        });
    }

    private void updateTransactionStatus(PaymentFeeTransaction transaction, String status) {
        try (Connection conn = connectToDatabase();
             PreparedStatement stmt = conn.prepareStatement("UPDATE PaymentFeeTransactions SET Status = ?, UpdatedDate = GETDATE() WHERE ID = ?")) {
            stmt.setString(1, status);
            stmt.setInt(2, transaction.getId());
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                transaction.setStatus(status); // Update the status in the transaction object

                // Disable further updates if status is Cancelled or Sent
                if ("Cancelled".equals(status) || "Sent".equals(status)) {
                    tableView.refresh(); // Refresh the table to show updated status
                }
            } else {
                // Handle case where no rows were updated (possibly due to constraint violation)
                System.out.println("No rows updated. Constraint violation?");
            }
        } catch (SQLServerException e) {
            if (e.getErrorCode() == 547) {
                System.out.println("Constraint violation: Cannot update status to '" + status + "'.");
                // Handle the constraint violation error here (e.g., notify user)
            } else {
                e.printStackTrace();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void fetchTransactionsForUserFromDatabase(ObservableList<PaymentFeeTransaction> transactions, String userEmail) {
        try (Connection conn = connectToDatabase();
             PreparedStatement stmt = conn.prepareStatement("SELECT p.ID, p.PaymentBank, p.AccountNumber, p.AccountName, p.Amount, p.Status, " +
                     "p.EffectiveDate, p.CreatedDate, p.UpdatedDate " +
                     "FROM PaymentFeeTransactions p " +
                     "INNER JOIN Students s ON p.StudentID = s.ID " +
                     "WHERE s.Email = ?")) {
            stmt.setString(1, userEmail);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                PaymentFeeTransaction transaction = new PaymentFeeTransaction(
                        rs.getInt("ID"),
                        rs.getString("PaymentBank"),
                        rs.getString("AccountNumber"),
                        rs.getString("AccountName"),
                        rs.getDouble("Amount"),
                        rs.getString("Status")
                );

                // Handle nullable Timestamp values
                Timestamp effectiveDateTimestamp = rs.getTimestamp("EffectiveDate");
                if (effectiveDateTimestamp != null) {
                    transaction.setEffectiveDate(effectiveDateTimestamp.toLocalDateTime());
                }

                Timestamp createdDateTimestamp = rs.getTimestamp("CreatedDate");
                if (createdDateTimestamp != null) {
                    transaction.setCreatedDate(createdDateTimestamp.toLocalDateTime());
                }

                Timestamp updatedDateTimestamp = rs.getTimestamp("UpdatedDate");
                if (updatedDateTimestamp != null) {
                    transaction.setUpdatedDate(updatedDateTimestamp.toLocalDateTime());
                }

                transactions.add(transaction);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void showTransactionDetails(PaymentFeeTransaction transaction) {
        // Create a new stage for the transaction details
        Stage detailStage = new Stage();
        detailStage.setTitle("Transaction Details");

        // Logo and Header
        ImageView logoImageView = new ImageView(new Image("file:C:/Users/seang/OneDrive/Desktop/rupp logo.png"));
        logoImageView.setFitHeight(80);
        logoImageView.setPreserveRatio(true);
        Label titleLabel = new Label("Transaction Details");
        titleLabel.setStyle("-fx-font-size: 20px; -fx-font-weight: bold;");
        HBox headerBox = new HBox(10, logoImageView, titleLabel);
        headerBox.setAlignment(Pos.CENTER);
        headerBox.setPadding(new Insets(20));
        headerBox.setStyle("-fx-background-color: #f0f0f0; -fx-effect: dropshadow(gaussian, rgba(0,0,0,0.2), 10, 0, 0, 0);");

        // Transaction Details Content
        VBox detailsBox = new VBox(10);
        detailsBox.setAlignment(Pos.CENTER_LEFT);
        detailsBox.setPadding(new Insets(20));
        detailsBox.setStyle("-fx-background-color: #ffffff; -fx-effect: dropshadow(gaussian, rgba(0,0,0,0.2), 10, 0, 0, 0);");

        // Transaction details text
        Label idLabel = new Label("ID: " + transaction.getId());
        Label bankLabel = new Label("Payment Bank: " + transaction.getPaymentBank());
        Label accountNumberLabel = new Label("Account Number: " + transaction.getAccountNumber());
        Label accountNameLabel = new Label("Account Name: " + transaction.getAccountName());
        Label amountLabel = new Label("Amount: " + transaction.getAmount());
        Label statusLabel = new Label("Status: " + transaction.getStatus());
        Label effectiveDateLabel = new Label("Effective Date: " + formatDateTime(transaction.getEffectiveDate()));
        Label createdDateLabel = new Label("Created Date: " + formatDateTime(transaction.getCreatedDate()));
        Label updatedDateLabel = new Label("Updated Date: " + formatDateTime(transaction.getUpdatedDate()));

        // Add details labels to VBox
        detailsBox.getChildren().addAll(idLabel, bankLabel, accountNumberLabel, accountNameLabel,
                amountLabel, statusLabel, effectiveDateLabel, createdDateLabel, updatedDateLabel);

        // Close button
        Button closeButton = new Button("Close");
        closeButton.setStyle("-fx-background-color: #4CAF50; -fx-text-fill: white; -fx-padding: 10px 20px;");
        closeButton.setOnAction(e -> detailStage.close());

        // Layout
        BorderPane layout = new BorderPane();
        layout.setTop(headerBox);
        layout.setCenter(detailsBox);
        layout.setBottom(closeButton);
        BorderPane.setAlignment(closeButton, Pos.CENTER);
        BorderPane.setMargin(closeButton, new Insets(20));

        // Scene
        Scene scene = new Scene(layout, 600, 400);
        detailStage.setScene(scene);
        detailStage.show();
    }


    private static String formatDateTime(LocalDateTime dateTime) {
        if (dateTime == null) {
            return "N/A";
        }
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        return dateTime.format(formatter);
    }

    public static void exportTransactionToPDF(PaymentFeeTransaction transaction) throws IOException {
        // Create PDF document
        PDDocument document = new PDDocument();
        PDPage page = new PDPage(PDRectangle.A4);
        document.addPage(page);

        // Initialize content stream
        PDPageContentStream contentStream = new PDPageContentStream(document, page);

        // Load the logo image
        PDImageXObject logo = PDImageXObject.createFromFile("C:/Users/seang/OneDrive/Desktop/rupp logo.png", document);
        float logoWidth = 100; // Adjust width of logo
        float logoHeight = logoWidth * logo.getHeight() / logo.getWidth();

        // Position logo on the left side, 50 points from top and left margins
        float logoX = 50;
        float logoY = PDRectangle.A4.getHeight() - 50 - logoHeight;
        contentStream.drawImage(logo, logoX, logoY, logoWidth, logoHeight);

        // Set font and other properties
        contentStream.setFont(PDType1Font.HELVETICA_BOLD, 14);
        contentStream.setLeading(20); // Adjust line spacing as needed

        // Title
        float titleX = logoX + logoWidth + 50; // Adjust spacing between logo and text
        float titleY = logoY + logoHeight - 14;
        contentStream.beginText();
        contentStream.newLineAtOffset(titleX, titleY);
        contentStream.showText("Transaction Details");
        contentStream.endText();

        // Transaction details
        float startX = 50;
        float startY = logoY - 40; // Adjust as needed
        contentStream.setFont(PDType1Font.HELVETICA, 12);

        String[][] details = {
                {"Transaction ID", String.valueOf(transaction.getId())},
                {"Payment Bank", transaction.getPaymentBank()},
                {"Account Number", transaction.getAccountNumber()},
                {"Account Name", transaction.getAccountName()},
                {"Amount", String.valueOf(transaction.getAmount())},
                {"Status", transaction.getStatus()},
                {"Effective Date", formatDateTime(transaction.getEffectiveDate())},
                {"Created Date", formatDateTime(transaction.getCreatedDate())},
                {"Updated Date", formatDateTime(transaction.getUpdatedDate())}
        };

        for (String[] detail : details) {
            contentStream.beginText();
            contentStream.newLineAtOffset(startX, startY);
            contentStream.showText(detail[0] + ": " + detail[1]);
            contentStream.endText();
            startY -= 20; // Move down for next line
        }

        // Close content stream
        contentStream.close();

        // Save the document to the specified path
        String outputPath = "C:/Users/seang/Downloads/Transaction_" + transaction.getId() + ".pdf";
        document.save(outputPath);
        document.close();

        // Show confirmation dialog (could be implemented in your GUI)
        System.out.println("Transaction details exported to PDF: " + outputPath);
    }

    public static void main(String[] args) {
        // Example usage
        PaymentFeeTransaction transaction = new PaymentFeeTransaction(1, "Bank A", "123456789", "John Doe", 1000.0, "Pending");
        transaction.setEffectiveDate(LocalDateTime.now());
        transaction.setCreatedDate(LocalDateTime.now());
        transaction.setUpdatedDate(LocalDateTime.now());

        try {
            exportTransactionToPDF(transaction);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    private void fetchTransactionDetails(PaymentFeeTransaction transaction, PDPageContentStream contentStream,
                                         float yPosition, float margin, float rowHeight, int cols) {
        try (Connection conn = connectToDatabase();
             PreparedStatement stmt = conn.prepareStatement("SELECT p.ID, p.PaymentBank, p.AccountNumber, p.AccountName, " +
                     "p.Amount, p.Status, p.EffectiveDate, p.CreatedDate, p.UpdatedDate " +
                     "FROM PaymentFeeTransactions p " +
                     "WHERE p.ID = ?")) {
            stmt.setInt(1, transaction.getId());
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                transaction.setPaymentBank(rs.getString("PaymentBank"));
                transaction.setAccountNumber(rs.getString("AccountNumber"));
                transaction.setAccountName(rs.getString("AccountName"));
                transaction.setAmount(rs.getDouble("Amount"));
                transaction.setStatus(rs.getString("Status"));

                // Handle nullable Timestamp values
                Timestamp effectiveDateTimestamp = rs.getTimestamp("EffectiveDate");
                if (effectiveDateTimestamp != null) {
                    transaction.setEffectiveDate(effectiveDateTimestamp.toLocalDateTime());
                }

                Timestamp createdDateTimestamp = rs.getTimestamp("CreatedDate");
                if (createdDateTimestamp != null) {
                    transaction.setCreatedDate(createdDateTimestamp.toLocalDateTime());
                }

                Timestamp updatedDateTimestamp = rs.getTimestamp("UpdatedDate");
                if (updatedDateTimestamp != null) {
                    transaction.setUpdatedDate(updatedDateTimestamp.toLocalDateTime());
                }

                // Write transaction details to PDF
                contentStream.setFont(PDType1Font.HELVETICA, 12);
                for (int i = 0; i < cols; i++) {
                    contentStream.beginText();
                    contentStream.newLineAtOffset(margin + (i * 100), yPosition - 40);
                    switch (i) {
                        case 0:
                            contentStream.showText(String.valueOf(transaction.getId()));
                            break;
                        case 1:
                            contentStream.showText(transaction.getPaymentBank());
                            break;
                        case 2:
                            contentStream.showText(transaction.getAccountNumber());
                            break;
                        case 3:
                            contentStream.showText(transaction.getAccountName());
                            break;
                        case 4:
                            contentStream.showText(String.valueOf(transaction.getAmount()));
                            break;
                        case 5:
                            contentStream.showText(transaction.getStatus());
                            break;
                        case 6:
                            contentStream.showText(formatDateTime(transaction.getEffectiveDate()));
                            break;
                        case 7:
                            contentStream.showText(formatDateTime(transaction.getCreatedDate()));
                            break;
                        case 8:
                            contentStream.showText(formatDateTime(transaction.getUpdatedDate()));
                            break;
                        default:
                            break;
                    }
                    contentStream.endText();
                }
            } else {
                // Handle case where no transaction found
                System.out.println("Transaction with ID " + transaction.getId() + " not found.");
            }
        } catch (SQLException | IOException e) {
            e.printStackTrace();
        }
    }


    private Connection connectToDatabase() throws SQLException {
        String url = "jdbc:sqlserver://localhost:51828;databaseName=test001";
        String username = "sa";
        String password = "Demo@123";
        return DriverManager.getConnection(url, username, password);
    }
}

