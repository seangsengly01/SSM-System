package com.example.ssm_version_2;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.effect.DropShadow;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

import java.sql.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.regex.Pattern;

public class SettingsPage {

    private Connection connectToDatabase() throws SQLException {
        String url = "jdbc:sqlserver://localhost:51828;databaseName=test001";
        String username = "sa";
        String password = "Demo@123";
        Connection conn = DriverManager.getConnection(url, username, password);
        checkAndAddJoinDateColumn(conn); // Check and add "JoinDate" column if it doesn't exist
        return conn;
    }

    private void checkAndAddJoinDateColumn(Connection conn) throws SQLException {
        DatabaseMetaData dbMetaData = conn.getMetaData();
        ResultSet rs = dbMetaData.getColumns(null, null, "Students", "JoinDate");
        if (!rs.next()) {
            try (Statement stmt = conn.createStatement()) {
                stmt.executeUpdate("ALTER TABLE Students ADD JoinDate DATE");
            }
        }
    }

    public void showSettings(String userEmail) {
        // Fetch user's information from the database
        String firstName = "";
        String lastName = "";
        String phoneNumber = "";
        String department = "";
        String birthday = "";
        String joinDate = "";

        try (Connection conn = connectToDatabase();
             PreparedStatement stmt = conn.prepareStatement("SELECT FirstName, LastName, PhoneNumber, Department, Birthday, JoinDate FROM Students WHERE Email = ?")) {
            stmt.setString(1, userEmail);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                firstName = rs.getString("FirstName");
                lastName = rs.getString("LastName");
                phoneNumber = rs.getString("PhoneNumber");
                department = rs.getString("Department");
                birthday = rs.getString("Birthday");
                if (rs.getString("JoinDate") != null) {
                    joinDate = rs.getString("JoinDate");
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        // Create form for settings
        GridPane grid = new GridPane();
        grid.setPadding(new Insets(20));
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setAlignment(Pos.CENTER);
        grid.setStyle("-fx-background-color: #f9f9f9; -fx-border-radius: 10; -fx-background-radius: 10;");
        grid.setEffect(new DropShadow(10, Color.GRAY));

        // Add form elements
        Label firstNameLabel = new Label("First Name:");
        TextField firstNameField = new TextField(firstName);
        Label lastNameLabel = new Label("Last Name:");
        TextField lastNameField = new TextField(lastName);
        Label phoneNumberLabel = new Label("Phone Number:");
        TextField phoneNumberField = new TextField(phoneNumber);
        Label departmentLabel = new Label("Major:");
        ComboBox<String> departmentComboBox = new ComboBox<>();
        departmentComboBox.getItems().addAll(
                "Khmer Language and Literature", "English Language", "History", "Geography", "Philosophy",
                "Economics", "Management", "International Studies", "Public Administration", "Psychology",
                "Mathematics", "Physics", "Chemistry", "Biology", "Computer Science", "Civil Engineering",
                "Electrical Engineering", "Mechanical Engineering", "Agriculture", "Food Science and Technology",
                "Primary Education", "Secondary Education"
        );
        departmentComboBox.setValue(department);
        Label birthdayLabel = new Label("Birthday:");
        DatePicker birthdayDatePicker = new DatePicker();
        birthdayDatePicker.setEditable(false);
        if (birthday != null && !birthday.isEmpty()) {
            birthdayDatePicker.setValue(LocalDate.parse(birthday, DateTimeFormatter.ISO_DATE));
        }
        birthdayDatePicker.setDayCellFactory(picker -> new DateCell() {
            public void updateItem(LocalDate date, boolean empty) {
                super.updateItem(date, empty);
                if (date != null && date.isAfter(LocalDate.now())) {
                    setDisable(true);
                }
            }
        });

        // Add Join Date elements
        Label joinDateLabel = new Label("Join Date:");
        DatePicker joinDatePicker = new DatePicker();
        joinDatePicker.setEditable(false);
        if (!joinDate.isEmpty()) {
            joinDatePicker.setValue(LocalDate.parse(joinDate, DateTimeFormatter.ISO_DATE));
        }
        joinDatePicker.setDayCellFactory(picker -> new DateCell() {
            public void updateItem(LocalDate date, boolean empty) {
                super.updateItem(date, empty);
                if (date.isAfter(LocalDate.now())) {
                    setDisable(true);
                }
            }
        });

        // Add validation labels
        Label validationLabel = new Label();
        validationLabel.setTextFill(Color.RED);

        grid.add(firstNameLabel, 0, 0);
        grid.add(firstNameField, 1, 0);
        grid.add(lastNameLabel, 0, 1);
        grid.add(lastNameField, 1, 1);
        grid.add(phoneNumberLabel, 0, 2);
        grid.add(phoneNumberField, 1, 2);
        grid.add(departmentLabel, 0, 3);
        grid.add(departmentComboBox, 1, 3);
        grid.add(birthdayLabel, 0, 4);
        grid.add(birthdayDatePicker, 1, 4);
        grid.add(joinDateLabel, 0, 5);
        grid.add(joinDatePicker, 1, 5);
        grid.add(validationLabel, 1, 6);

        // Add save button
        Button saveButton = new Button("Save");
        saveButton.setStyle("-fx-background-color: #4CAF50; -fx-text-fill: white; -fx-font-weight: bold;");
        saveButton.setOnAction(event -> {
            // Input validation
            if (!validateInputs(firstNameField, lastNameField, phoneNumberField, departmentComboBox, birthdayDatePicker, joinDatePicker, validationLabel)) {
                return;
            }

            // Update user information in the database
            try (Connection conn = connectToDatabase();
                 PreparedStatement stmt = conn.prepareStatement("UPDATE Students SET FirstName = ?, LastName = ?, PhoneNumber = ?, Department = ?, Birthday = ?, JoinDate = ? WHERE Email = ?")) {
                stmt.setString(1, firstNameField.getText());
                stmt.setString(2, lastNameField.getText());
                stmt.setString(3, phoneNumberField.getText());
                stmt.setString(4, departmentComboBox.getValue());
                stmt.setString(5, birthdayDatePicker.getValue().toString());
                stmt.setString(6, joinDatePicker.getValue().toString());
                stmt.setString(7, userEmail);
                stmt.executeUpdate();

                // Provide feedback to the user upon successful save
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Settings Saved");
                alert.setHeaderText(null);
                alert.setContentText("Your settings have been saved successfully.");
                alert.showAndWait();
            } catch (SQLException ex) {
                ex.printStackTrace();
                // Handle errors and provide feedback to the user
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Error");
                alert.setHeaderText(null);
                alert.setContentText("An error occurred while saving your settings. Please try again.");
                alert.showAndWait();
            }
        });

        // Add "Back to Dashboard" button
        Button backButton = new Button("Back to Dashboard");
        backButton.setStyle("-fx-background-color: #2196F3; -fx-text-fill: white; -fx-font-weight: bold;");
        backButton.setOnAction(event -> {
            DashboardPage dashboardPage = new DashboardPage();
            try {
                dashboardPage.start((Stage) backButton.getScene().getWindow());
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });

        HBox buttonBox = new HBox(10);
        buttonBox.setAlignment(Pos.CENTER);
        buttonBox.getChildren().addAll(saveButton, backButton);

        grid.add(buttonBox, 1, 7);

        // Add logo image
        Image logoImage = new Image("file:C:/Users/seang/OneDrive/Desktop/rupp logo.png");
        ImageView logoImageView = new ImageView(logoImage);
        logoImageView.setFitHeight(100);
        logoImageView.setPreserveRatio(true);

        // Add welcome label
        Label welcomeLabel = new Label("Welcome to SSM System");
        welcomeLabel.setStyle("-fx-font-size: 20px; -fx-font-weight: bold;");

        // Create a VBox to hold the logo and welcome label
        VBox logoBox = new VBox(10);
        logoBox.setAlignment(Pos.CENTER);
        logoBox.getChildren().addAll(logoImageView, welcomeLabel);

        VBox vbox = new VBox(20);
        vbox.setPadding(new Insets(20));
        vbox.setAlignment(Pos.CENTER);
        vbox.setStyle("-fx-background-color: #ffffff;");
        vbox.getChildren().addAll(logoBox, grid);

        // Show the settings page
        Scene scene = new Scene(vbox);
        Stage stage = new Stage();
        stage.setTitle("Settings");

        stage.setScene(scene);
        stage.setFullScreen(true); // Set full screen mode
        stage.show();
    }

    private boolean validateInputs(TextField firstNameField, TextField lastNameField, TextField phoneNumberField, ComboBox<String> departmentComboBox, DatePicker birthdayDatePicker, DatePicker joinDatePicker, Label validationLabel) {
        if (firstNameField.getText().isEmpty() || lastNameField.getText().isEmpty() || phoneNumberField.getText().isEmpty() || departmentComboBox.getValue() == null || birthdayDatePicker.getValue() == null || joinDatePicker.getValue() == null) {
            validationLabel.setText("All fields are required.");
            return false;
        }
        if (!Pattern.matches("\\d{0,14}", phoneNumberField.getText())) {
            validationLabel.setText("Phone number must be less than 10 digits.");
            return false;
        }
        if (birthdayDatePicker.getValue().isAfter(LocalDate.now()) || joinDatePicker.getValue().isAfter(LocalDate.now())) {
            validationLabel.setText("Dates cannot be in the future.");
            return false;
        }
        validationLabel.setText("");
        return true;
    }
}
