package com.example.ssm_version_2;

import javafx.animation.PauseTransition;
import javafx.application.Application;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.effect.DropShadow;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ForgetPasswordPage extends Application {

    private final String DB_URL = "jdbc:sqlserver://localhost:51786;databaseName=test001";
    private final String DB_USER = "sa";
    private final String DB_PASSWORD = "Demo@123";

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("SSM Forget Password");


        // Logo
        Image logoImage = new Image("file:C:/Users/seang/OneDrive/Desktop/rupp logo.png");
        ImageView logoImageView = new ImageView(logoImage);
        logoImageView.setFitHeight(100);
        logoImageView.setPreserveRatio(true);

        // Title
        Label titleLabel = new Label("Reset Your Password");
        titleLabel.setStyle("-fx-font-size: 18pt; -fx-font-weight: bold;");

        // Form fields
        TextField emailField = new TextField();
        emailField.setPromptText("Enter student email");

        TextField studentIDField = new TextField();
        studentIDField.setPromptText("Enter student ID");

        PasswordField newPasswordField = new PasswordField();
        newPasswordField.setPromptText("Enter new password");
        newPasswordField.setDisable(true);

        PasswordField confirmPasswordField = new PasswordField();
        confirmPasswordField.setPromptText("Confirm new password");
        confirmPasswordField.setDisable(true);

        // Error messages
        Label emailErrorLabel = new Label();
        emailErrorLabel.setStyle("-fx-text-fill: red;");
        emailErrorLabel.setVisible(false);

        Label studentIDErrorLabel = new Label();
        studentIDErrorLabel.setStyle("-fx-text-fill: red;");
        studentIDErrorLabel.setVisible(false);

        Label passwordErrorLabel = new Label();
        passwordErrorLabel.setStyle("-fx-text-fill: red;");
        passwordErrorLabel.setVisible(false);

        // Add email validation
        emailField.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.matches("\\w+([.-]?\\w+)*@rupp\\.edu\\.kh")) {
                emailField.setStyle("-fx-border-color: red;");
                emailErrorLabel.setText("Invalid email format.");
                emailErrorLabel.setVisible(true);
            } else {
                emailField.setStyle(""); // Reset style
                emailErrorLabel.setVisible(false);
            }
        });

        // Add student ID validation
        studentIDField.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.matches("\\d*")) {
                studentIDField.setStyle("-fx-border-color: red;");
                studentIDErrorLabel.setText("Student ID must be numeric.");
                studentIDErrorLabel.setVisible(true);
            } else {
                studentIDField.setStyle(""); // Reset style
                studentIDErrorLabel.setVisible(false);
            }
        });

        // Buttons
        Button verifyButton = new Button("Verify");
        Button resetPasswordButton = new Button("Reset Password");
        Button backButton = new Button("Back to Login");

        // Set action for the back button to switch to LoginPage
        backButton.setOnAction(e -> {
            LoginPage loginPage = new LoginPage();
            try {
                loginPage.start(primaryStage);
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });

        // Set action for the verify button
        verifyButton.setOnAction(e -> {
            String email = emailField.getText();
            String studentID = studentIDField.getText();

            if (email.isEmpty()) {
                emailErrorLabel.setText("Email cannot be empty.");
                emailErrorLabel.setVisible(true);
            } else if (studentID.isEmpty()) {
                studentIDErrorLabel.setText("Student ID cannot be empty.");
                studentIDErrorLabel.setVisible(true);
            } else if (email.matches("\\w+([.-]?\\w+)*@rupp\\.edu\\.kh") && studentID.matches("\\d*") && verifyStudent(email, studentID)) {
                newPasswordField.setDisable(false);
                confirmPasswordField.setDisable(false);
                emailErrorLabel.setVisible(false);
                studentIDErrorLabel.setVisible(false);
            } else {
                newPasswordField.setDisable(true);
                confirmPasswordField.setDisable(true);
                emailErrorLabel.setText("Invalid email or student ID.");
                emailErrorLabel.setVisible(true);
            }
        });

        // Set action for the reset password button
        resetPasswordButton.setOnAction(e -> {
            String email = emailField.getText();
            String studentID = studentIDField.getText();
            String newPassword = newPasswordField.getText();
            String confirmPassword = confirmPasswordField.getText();

            if (newPassword.isEmpty() || !newPassword.equals(confirmPassword)) {
                passwordErrorLabel.setText("Passwords do not match or are empty.");
                passwordErrorLabel.setVisible(true);

            } else {
                resetPassword(email, studentID, newPassword);
//                passwordErrorLabel.setVisible(false);
                showSuccessScreen(primaryStage);
            }

        });

        // Layout setup
        GridPane gridPane = new GridPane();
        gridPane.setAlignment(Pos.CENTER);
        gridPane.setHgap(10);
        gridPane.setVgap(10);
        gridPane.setPadding(new Insets(10, 10, 10, 10));

        // Adding nodes to GridPane
        gridPane.add(new Label("Student Email:"), 0, 0);
        gridPane.add(emailField, 1, 0);
        gridPane.add(emailErrorLabel, 1, 1);

        gridPane.add(new Label("Student ID:"), 0, 2);
        gridPane.add(studentIDField, 1, 2);
        gridPane.add(studentIDErrorLabel, 1, 3);
        gridPane.add(new Label(""), 0, 4);  // Empty label for spacing
        gridPane.add(verifyButton, 1, 4);

        gridPane.add(new Label("New Password:"), 0, 5);
        gridPane.add(newPasswordField, 1, 5);
        gridPane.add(passwordErrorLabel, 1, 6);

        gridPane.add(new Label("Confirm Password:"), 0, 7);
        gridPane.add(confirmPasswordField, 1, 7);

        // Spacer
        Region spacer = new Region();
        spacer.setPrefHeight(20);  // Adjust the height as needed for space
        gridPane.add(spacer, 0, 8, 2, 1);

        HBox buttonsBox = new HBox(10);
        buttonsBox.setAlignment(Pos.CENTER);
        buttonsBox.getChildren().addAll(resetPasswordButton, backButton);

        VBox formBox = new VBox(20);
        formBox.setMaxWidth(550);
        formBox.setAlignment(Pos.CENTER);
        formBox.getChildren().addAll(titleLabel, gridPane, buttonsBox);
        formBox.setPadding(new Insets(20));
        formBox.setStyle("-fx-background-color: white; -fx-border-radius: 10; -fx-background-radius: 10;");

        // Add shadow effect to formBox
        DropShadow shadow = new DropShadow();
        shadow.setRadius(10.0);
        shadow.setOffsetX(5.0);
        shadow.setOffsetY(5.0);
        shadow.setColor(Color.color(0.4, 0.5, 0.5));
        formBox.setEffect(shadow);

        VBox vbox = new VBox(20);
        vbox.setAlignment(Pos.CENTER);
        vbox.getChildren().addAll(logoImageView, formBox);
        vbox.setPadding(new Insets(20));

        // Set background image
        StackPane root = new StackPane();
        root.setStyle("-fx-background-image: url('file:C:/Users/seang/OneDrive/Desktop/rupp logo.png'); " +
                "-fx-background-size: cover; " +
                "-fx-background-position: center center; " +
                "-fx-background-repeat: no-repeat;");

        root.getChildren().add(vbox);

        Scene scene = new Scene(root);
        primaryStage.setScene(scene);
        primaryStage.setFullScreen(true); // Open in full-screen mode
        primaryStage.show();
    }

    private boolean verifyStudent(String email, String studentID) {
        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            String query = "SELECT COUNT(*) FROM Students WHERE Email = ? AND StudentID = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, email);
            preparedStatement.setString(2, studentID);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next() && resultSet.getInt(1) > 0) {
                return true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    private void resetPassword(String email, String studentID, String newPassword) {
        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            String updateQuery = "UPDATE Students SET Password = ? WHERE Email = ? AND StudentID = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(updateQuery);
            preparedStatement.setString(1, newPassword);
            preparedStatement.setString(2, email);
            preparedStatement.setString(3, studentID);
            int rowsAffected = preparedStatement.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("Password reset successful.");
            } else {
                System.out.println("Password reset failed. Please check your email and student ID.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void showSuccessScreen(Stage primaryStage) {
        Label successLabel = new Label("Password reset successful!");
        successLabel.setStyle("-fx-font-size: 18pt; -fx-font-weight: bold;");

        Label waitLabel = new Label("Please wait a moment. You will be redirected to the login page.");
        waitLabel.setStyle("-fx-font-size: 14pt;");

        VBox successBox = new VBox(20);
        successBox.setAlignment(Pos.CENTER);
        successBox.getChildren().addAll(successLabel, waitLabel);
        successBox.setPadding(new Insets(20));
        successBox.setStyle("-fx-background-color: white; -fx-border-radius: 10; -fx-background-radius: 10;");

        // Add shadow effect to successBox
        DropShadow shadow = new DropShadow();
        shadow.setRadius(10.0);
        shadow.setOffsetX(5.0);
        shadow.setOffsetY(5.0);
        shadow.setColor(Color.color(0.4, 0.5, 0.5));
        successBox.setEffect(shadow);

        StackPane root = new StackPane(successBox);
        root.setStyle("-fx-background-image: url('file:C:/Users/seang/OneDrive/Desktop/rupp logo.png'); " +
                "-fx-background-size: cover; " +
                "-fx-background-position: center center; " +
                "-fx-background-repeat: no-repeat;");

        Scene scene = new Scene(root);
        primaryStage.setScene(scene);
        primaryStage.setFullScreen(true);

        // Redirect to login page after a delay
        PauseTransition delay = new PauseTransition(Duration.seconds(5)); // 5 seconds delay
        delay.setOnFinished(event -> {
            LoginPage loginPage = new LoginPage();
            try {
                loginPage.start(primaryStage);
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });
        delay.play();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
