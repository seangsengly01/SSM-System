package com.example.ssm_version_2;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.effect.DropShadow;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class StudentProfilePage {

    private Connection connectToDatabase() throws SQLException {
        String url = "jdbc:sqlserver://localhost:51828;databaseName=test001";
        String username = "sa";
        String password = "Demo@123";
        Connection conn = DriverManager.getConnection(url, username, password);
        return conn;
    }

    public void showStudentProfile(String userEmail) {
        // Fetch user's information from the database
        String firstName = "";
        String lastName = "";
        String phoneNumber = "";
        String department = "";
        String birthday = "";
        String joinDate = "";

        try (Connection conn = connectToDatabase();
             PreparedStatement stmt = conn.prepareStatement("SELECT FirstName, LastName, PhoneNumber, Department, Birthday, JoinDate FROM Students WHERE Email = ?")) {
            stmt.setString(1, userEmail);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                firstName = rs.getString("FirstName");
                lastName = rs.getString("LastName");
                phoneNumber = rs.getString("PhoneNumber");
                department = rs.getString("Department");
                birthday = rs.getString("Birthday");
                joinDate = rs.getString("JoinDate");
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        // Create form for student profile
        GridPane grid = new GridPane();
        grid.setPadding(new Insets(20));
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setAlignment(Pos.CENTER);
        grid.setStyle("-fx-background-color: #f9f9f9; -fx-border-radius: 10; -fx-background-radius: 10;");
        grid.setEffect(new DropShadow(10, Color.GRAY));

        // Add form elements
        Label firstNameLabel = new Label("First Name:");
        Label firstNameValueLabel = new Label(firstName);
        Label lastNameLabel = new Label("Last Name:");
        Label lastNameValueLabel = new Label(lastName);
        Label phoneNumberLabel = new Label("Phone Number:");
        Label phoneNumberValueLabel = new Label(phoneNumber);
        Label departmentLabel = new Label("Major:");
        Label departmentValueLabel = new Label(department);
        Label birthdayLabel = new Label("Birthday:");
        Label birthdayValueLabel = new Label(birthday);
        Label joinDateLabel = new Label("Join Date:");
        Label joinDateValueLabel = new Label(joinDate);

        grid.add(firstNameLabel, 0, 0);
        grid.add(firstNameValueLabel, 1, 0);
        grid.add(lastNameLabel, 0, 1);
        grid.add(lastNameValueLabel, 1, 1);
        grid.add(phoneNumberLabel, 0, 2);
        grid.add(phoneNumberValueLabel, 1, 2);
        grid.add(departmentLabel, 0, 3);
        grid.add(departmentValueLabel, 1, 3);
        grid.add(birthdayLabel, 0, 4);
        grid.add(birthdayValueLabel, 1, 4);
        grid.add(joinDateLabel, 0, 5);
        grid.add(joinDateValueLabel, 1, 5);

        // Add logo image
        Image logoImage = new Image("file:C:/Users/seang/OneDrive/Desktop/rupp logo.png");
        ImageView logoImageView = new ImageView(logoImage);
        logoImageView.setFitHeight(100);
        logoImageView.setPreserveRatio(true);

        // Add student profile label
        Label studentProfileLabel = new Label("Student Profile");
        studentProfileLabel.setStyle("-fx-font-size: 20px; -fx-font-weight: bold;");

        // Create a VBox to hold the logo and student profile label
        VBox logoBox = new VBox(10);
        logoBox.setAlignment(Pos.CENTER);
        logoBox.getChildren().addAll(logoImageView, studentProfileLabel);

        // Create a Back button
        Button backButton = new Button("Back");
        backButton.setStyle("-fx-background-color: #ff0000; -fx-text-fill: #ffffff; -fx-font-weight: bold;");
        backButton.setOnAction(e -> {
            // Close the current stage
            Stage stage = (Stage) backButton.getScene().getWindow();
            stage.close();

            // Navigate back to the Dashboard page
            DashboardPage dashboard = new DashboardPage();
            dashboard.showDashboard(new Stage(), userEmail);
        });

        VBox vbox = new VBox(20);
        vbox.setPadding(new Insets(20));
        vbox.setAlignment(Pos.CENTER);
        vbox.setStyle("-fx-background-color: #ffffff;");
        vbox.getChildren().addAll(logoBox, grid, backButton);

        // Show the student profile page
        Scene scene = new Scene(vbox);
        Stage stage = new Stage();
        stage.setTitle("Student Profile");

        stage.setScene(scene);
        stage.setFullScreen(true); // Set full screen mode
        stage.show();
    }
}
