package com.example.ssm_version_2;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.geometry.Side;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.effect.DropShadow;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

import java.sql.*;

public class DashboardPage extends Application {

    private Stage primaryStage;
    private String userEmail;

    private ContextMenu menuDropDown; // Declaring menuDropDown here

    @Override
    public void start(Stage primaryStage) throws Exception {
        this.primaryStage = primaryStage;
        showDashboard(primaryStage, "user@example.com");
    }

    private Connection connectToDatabase() throws SQLException {
        String url = "jdbc:sqlserver://localhost:51828;databaseName=test001";
        String username = "sa";
        String password = "Demo@123";
        return DriverManager.getConnection(url, username, password);
    }

    private String getUserNameFromDatabase(String email) {
        String name = "";
        try (Connection conn = connectToDatabase();
             PreparedStatement stmt = conn.prepareStatement("SELECT FirstName, LastName FROM Students WHERE Email = ?")) {
            stmt.setString(1, email);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                String firstName = rs.getString("FirstName");
                String lastName = rs.getString("LastName");
                name = (firstName != null ? firstName : "") + " " + (lastName != null ? lastName : "");
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return name.trim();
    }

    public void showDashboard(Stage primaryStage, String userEmail) {
        this.primaryStage = primaryStage;
        this.userEmail = userEmail;

        primaryStage.setTitle("Dashboard");

        // Fetch user's name from the database
        String userName = getUserNameFromDatabase(userEmail);

        // Header Section
        Label nameLabel = new Label("Welcome, " + (userName.isEmpty() ? userEmail : userName));
        nameLabel.setStyle("-fx-font-size: 20px; -fx-font-weight: bold;");
        ImageView logoImageView = new ImageView(new Image("file:C:/Users/seang/OneDrive/Desktop/rupp logo.png"));
        logoImageView.setFitHeight(100);
        logoImageView.setPreserveRatio(true);
        VBox headerBox = new VBox(10, logoImageView, nameLabel);
        headerBox.setAlignment(Pos.CENTER);
        headerBox.setPadding(new Insets(20));

        // Navigation Buttons
        Button homeButton = createStyledButton("Home");
        Button settingsButton = createStyledButton("Settings");
        Button logoutButton = createStyledButton("Logout");
        homeButton.setOnAction(e -> System.out.println("Home button clicked"));
        settingsButton.setOnAction(e -> {
            primaryStage.close();
            SettingsPage settingsPage = new SettingsPage();
            settingsPage.showSettings(userEmail);
        });
        logoutButton.setOnAction(e -> {
            primaryStage.close();
            LoginPage loginPage = new LoginPage();
            try {
                loginPage.start(primaryStage);
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });

        // Menu Button
        Button menuButton = createStyledButton("Menu");
        menuButton.setOnAction(e -> menuDropDown.show(menuButton, Side.BOTTOM, 0, 0));

        // Dropdown Items
        MenuItem studentProfileItem = new MenuItem("Student Profile");
        MenuItem viewScoreItem = new MenuItem("View Score");
        MenuItem paySchoolFeeItem = new MenuItem("Pay School Fee");
        MenuItem transcriptionOnlineItem = new MenuItem("Transcription Online");

        // Dropdown Menu
        menuDropDown = new ContextMenu(studentProfileItem, viewScoreItem, paySchoolFeeItem, transcriptionOnlineItem);

        // Dropdown Item Actions
        studentProfileItem.setOnAction(e -> {
            primaryStage.close(); // Close dashboard page
            StudentProfilePage profilePage = new StudentProfilePage();
            profilePage.showStudentProfile(userEmail);
        });
        viewScoreItem.setOnAction(e -> System.out.println("View Score selected"));
        paySchoolFeeItem.setOnAction(e -> {
            primaryStage.close();
            PaySchoolFeePage paySchoolFeePage = new PaySchoolFeePage();
            paySchoolFeePage.showPaySchoolFee(primaryStage, userEmail);
        });
        transcriptionOnlineItem.setOnAction(e -> System.out.println("Transcription Online selected"));

        // Button Box
        HBox buttonBox = new HBox(20, homeButton, menuButton, settingsButton, logoutButton);
        buttonBox.setAlignment(Pos.CENTER);

        // Load the background image
        Image backgroundImage = new Image("file:C:/Users/seang/Downloads/Telegram Desktop/A2.jpg");
        BackgroundImage background = new BackgroundImage(backgroundImage, BackgroundRepeat.NO_REPEAT,
                BackgroundRepeat.NO_REPEAT, BackgroundPosition.CENTER, new BackgroundSize(BackgroundSize.AUTO,
                BackgroundSize.AUTO, false, false, true, false));

        // Set the background
        VBox layer1 = new VBox();
        layer1.setBackground(new Background(background));
        layer1.setPrefWidth(primaryStage.getWidth() * 0.7); // Adjust width as needed

        // Main Layout (BorderPane)
        BorderPane mainLayout = new BorderPane();
        mainLayout.setPadding(new Insets(20));
        mainLayout.setStyle("-fx-background-color: #f0f0f0;");

        // Add Layer #1 to the right side
        mainLayout.setRight(layer1);

        // Add Layer #2 to the center
        VBox layer2 = new VBox(20, headerBox, buttonBox);
        layer2.setAlignment(Pos.CENTER);
        mainLayout.setCenter(layer2);

        // Scene
        Scene scene = new Scene(mainLayout);
        primaryStage.setScene(scene);
        primaryStage.setFullScreen(true);
        primaryStage.show();
    }

    private Button createStyledButton(String text) {
        Button button = new Button(text);
        button.setStyle("-fx-background-color: #4CAF50; -fx-text-fill: white; -fx-font-weight: bold; -fx-padding: 10px 20px;");
        button.setEffect(new DropShadow(10, Color.GRAY));
        return button;
    }

    public static void main(String[] args) {
        launch(args);
    }
}
