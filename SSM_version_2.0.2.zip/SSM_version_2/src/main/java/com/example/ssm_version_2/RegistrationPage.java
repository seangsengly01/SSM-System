package com.example.ssm_version_2;

import javafx.animation.PauseTransition;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.effect.DropShadow;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.sql.*;

public class RegistrationPage extends Application {

    private static final String DB_URL = "jdbc:sqlserver://localhost:51828;databaseName=test001";
    private static final String DB_USER = "sa";
    private static final String DB_PASSWORD = "Demo@123";

    private TextField emailField;
    private TextField usernameField;
    private PasswordField passwordField;
    private PasswordField confirmPasswordField;

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("SSM Registration System");
//
//        // Initialize database and create table
//        initializeDatabase();

        // Logo
        Image logoImage = new Image("file:C:/Users/seang/OneDrive/Desktop/rupp logo.png");
        ImageView logoImageView = new ImageView(logoImage);
        logoImageView.setFitHeight(100);
        logoImageView.setPreserveRatio(true);

        // Title
        Label titleLabel = new Label("Welcome Registration to SSM System");
        titleLabel.setStyle("-fx-font-size: 18pt; -fx-font-weight: bold;");

        // Form fields
        emailField = new TextField();
        emailField.setPromptText("Enter student email");
        emailField.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.matches("\\w+([.-]?\\w+)*@rupp\\.edu\\.kh")) {
                emailField.setStyle("-fx-border-color: red;");
            } else {
                emailField.setStyle(""); // Reset style
            }
        });

        usernameField = new TextField();
        usernameField.setPromptText("Enter Student ID");
        usernameField.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.matches("\\d*")) {
                usernameField.setText(oldValue);
            }
        });

        passwordField = new PasswordField();
        passwordField.setPromptText("Enter password");
        passwordField.textProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue.length() < 6) {
                passwordField.setStyle("-fx-border-color: red;");
            } else {
                passwordField.setStyle(""); // Reset style
            }
        });

        confirmPasswordField = new PasswordField();
        confirmPasswordField.setPromptText("Confirm password");
        confirmPasswordField.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.equals(passwordField.getText())) {
                confirmPasswordField.setStyle("-fx-border-color: red;");
            } else {
                confirmPasswordField.setStyle(""); // Reset style
            }
        });

        // Buttons
        Button registerButton = new Button("Register");
        Button backButton = new Button("Back");

        // Set action for the back button to switch to LoginPage
        backButton.setOnAction(e -> {
            LoginPage loginPage = new LoginPage();
            try {
                loginPage.start(primaryStage);
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });

        // Set action for the register button
        registerButton.setOnAction(e -> {
            if (validateFields()) {
                registerStudent(primaryStage);
            } else {
                showAlert("Error", "Please fill in all the fields correctly.");
            }
        });

        // Layout setup
        GridPane gridPane = new GridPane();
        gridPane.setAlignment(Pos.CENTER);
        gridPane.setHgap(10);
        gridPane.setVgap(10);
        gridPane.setPadding(new Insets(10, 10, 10, 10));

        // Adding nodes to GridPane
        gridPane.add(new Label("Student Email:"), 0, 0);
        gridPane.add(emailField, 1, 0);
        gridPane.add(new Label("ID Student:"), 0, 1);
        gridPane.add(usernameField, 1, 1);
        gridPane.add(new Label("Password:"), 0, 2);
        gridPane.add(passwordField, 1, 2);
        gridPane.add(new Label("Confirm Password:"), 0, 3);
        gridPane.add(confirmPasswordField, 1, 3);

        // Spacer
        Region spacer = new Region();
        spacer.setPrefHeight(20);  // Adjust the height as needed for two lines of space
        gridPane.add(spacer, 0, 4, 2, 1);

        gridPane.add(registerButton, 1, 5);
        gridPane.add(backButton, 0, 5);

        VBox formBox = new VBox(20);
        formBox.setMaxWidth(500);
        formBox.setAlignment(Pos.CENTER);
        formBox.getChildren().addAll(titleLabel, gridPane);
        formBox.setPadding(new Insets(20));
        formBox.setStyle("-fx-background-color: white; -fx-border-radius: 10; -fx-background-radius: 10;");

        // Add shadow effect to formBox
        DropShadow shadow = new DropShadow();
        shadow.setRadius(10.0);
        shadow.setOffsetX(5.0);
        shadow.setOffsetY(5.0);
        shadow.setColor(Color.color(0.4, 0.5, 0.5));
        formBox.setEffect(shadow);

        VBox vbox = new VBox(20);
        vbox.setAlignment(Pos.CENTER);
        vbox.getChildren().addAll(logoImageView, formBox);
        vbox.setPadding(new Insets(20));

        // Set background image
        StackPane root = new StackPane();
        root.setStyle("-fx-background-image: url('file:C:/Users/seang/OneDrive/Desktop/rupp logo.png'); " +
                "-fx-background-size: cover; " +
                "-fx-background-position: center center; " +
                "-fx-background-repeat: no-repeat;");

        root.getChildren().add(vbox);

        Scene scene = new Scene(root);
        primaryStage.setScene(scene);
        primaryStage.setFullScreen(true); // Open in full-screen mode
        primaryStage.show();
    }

    private boolean validateFields() {
        boolean valid = true;

        // Validate email
        if (!emailField.getText().matches("\\w+([.-]?\\w+)*@rupp\\.edu\\.kh")) {
            emailField.setStyle("-fx-border-color: red;");
            valid = false;
        } else {
            emailField.setStyle(""); // Reset style
        }

        // Validate student ID
        if (!usernameField.getText().matches("\\d+")) {
            usernameField.setStyle("-fx-border-color: red;");
            valid = false;
        } else {
            usernameField.setStyle(""); // Reset style
        }

        // Validate password
        if (passwordField.getText().length() < 6) {
            passwordField.setStyle("-fx-border-color: red;");
            valid = false;
        } else {
            passwordField.setStyle(""); // Reset style
        }

        // Validate confirm password
        if (!confirmPasswordField.getText().equals(passwordField.getText())) {
            confirmPasswordField.setStyle("-fx-border-color: red;");
            valid = false;
        } else {
            confirmPasswordField.setStyle(""); // Reset style
        }

        return valid;
    }

//    private void initializeDatabase() {
//        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
//             Statement stmt = conn.createStatement()) {
//
//            String sqlCreate = "IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Students' and xtype='U') "
//                    + "CREATE TABLE Students ("
//                    + "ID BIGINT PRIMARY KEY IDENTITY(1,1), "
//                    + "Email VARCHAR(50) NOT NULL UNIQUE, "
//                    + "StudentID BIGINT NOT NULL UNIQUE, "
//                    + "Password VARCHAR(50) NOT NULL, "
//                    + "FirstName VARCHAR(50), "
//                    + "LastName VARCHAR(50), "
//                    + "PhoneNumber VARCHAR(15), "
//                    + "Department VARCHAR(50), "
//                    + "Birthday DATE, "
//                    + "JoinDate DATE"
//                    + ")";
//            stmt.execute(sqlCreate);
//            System.out.println("Table created successfully.");
//
//        } catch (SQLException e) {
//            e.printStackTrace();
//        }
//    }
private void initializeDatabase() {
    try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
         Statement stmt = conn.createStatement()) {

        String sqlCreate = "IF NOT EXISTS (SELECT table_name FROM information_schema.tables  WHERE table_name = 'Students') "
                + "CREATE TABLE Students ("
                + "ID BIGINT PRIMARY KEY IDENTITY(1,1), "
                + "Email VARCHAR(50) NOT NULL UNIQUE, "
                + "StudentID BIGINT NOT NULL UNIQUE, "
                + "Password VARCHAR(50) NOT NULL, "
                + "FirstName VARCHAR(50), "
                + "LastName VARCHAR(50), "
                + "PhoneNumber VARCHAR(15), "
                + "Department VARCHAR(50), "
                + "Birthday DATE, "
                + "JoinDate DATE"
                + ")";
        stmt.execute(sqlCreate);
        System.out.println("Table created successfully.");

    } catch (SQLException e) {
        e.printStackTrace();
    }
}

    private void registerStudent(Stage primaryStage) {
        String email = emailField.getText();
        String studentIDText = usernameField.getText();
        String password = passwordField.getText();
        String confirmPassword = confirmPasswordField.getText();

        // Check if any field is empty
        if (email.isEmpty() || studentIDText.isEmpty() || password.isEmpty() || confirmPassword.isEmpty()) {
            showAlert("Error", "Please fill in all the fields.");
            return; // Exit the method
        }

        // Check if email already exists
        if (isEmailExists(email)) {
            showAlert("Error", "Email already exists. Please try again.");
            emailField.setStyle("-fx-border-color: red;");
            return; // Exit the method
        }

        // Check if student ID already exists
        long studentID;
        try {
            studentID = Long.parseLong(studentIDText);
        } catch (NumberFormatException e) {
            showAlert("Error", "Invalid Student ID format. Please enter a valid number.");
            usernameField.setStyle("-fx-border-color: red;");
            return; // Exit the method
        }

        if (isStudentIDExists(studentID)) {
            showAlert("Error", "Student ID already exists. Please try again.");
            usernameField.setStyle("-fx-border-color: red;");
            return; // Exit the method
        }

        // Check if password and confirm password match
        if (!password.equals(confirmPassword)) {
            showAlert("Error", "Passwords do not match. Please re-enter your password.");
            passwordField.setStyle("-fx-border-color: red;");
            confirmPasswordField.setStyle("-fx-border-color: red;");
            return; // Exit the method
        }

        // If all validations pass, proceed with
        // Initialize database and create table,
        initializeDatabase();
        String sqlInsert = "INSERT INTO Students (Email, StudentID, Password) VALUES (?, ?, ?)";

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(sqlInsert)) {

            pstmt.setString(1, email);
            pstmt.setLong(2, studentID);
            pstmt.setString(3, password);

            int rowsAffected = pstmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Student registered successfully.");
                showSuccessScreen(primaryStage);
            }

        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Error", "An error occurred while registering. Please try again.");
        }
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private boolean isEmailExists(String email) {
        String sqlCheckEmail = "SELECT COUNT(*) FROM Students WHERE Email = ?";
        return isRecordExists(sqlCheckEmail, email);
    }

    private boolean isStudentIDExists(long studentID) {
        String sqlCheckStudentID = "SELECT COUNT(*) FROM Students WHERE StudentID = ?";
        return isRecordExists(sqlCheckStudentID, studentID);
    }

    private boolean isRecordExists(String sqlQuery, Object value) {
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(sqlQuery)) {

            if (value instanceof String) {
                pstmt.setString(1, (String) value);
            } else if (value instanceof Long) {
                pstmt.setLong(1, (long) value);
            }

            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    int count = rs.getInt(1);
                    return count > 0;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    private void showSuccessScreen(Stage primaryStage) {
        Label successLabel = new Label("Registration successful!");
        successLabel.setStyle("-fx-font-size: 18pt; -fx-font-weight: bold;");

        Label waitLabel = new Label("Please wait a moment. You will be redirected to the login page.");
        waitLabel.setStyle("-fx-font-size: 14pt;");

        VBox successBox = new VBox(20);
        successBox.setAlignment(Pos.CENTER);
        successBox.getChildren().addAll(successLabel, waitLabel);
        successBox.setPadding(new Insets(20));
        successBox.setStyle("-fx-background-color: white; -fx-border-radius: 10; -fx-background-radius: 10;");

        // Add shadow effect to successBox
        DropShadow shadow = new DropShadow();
        shadow.setRadius(10.0);
        shadow.setOffsetX(5.0);
        shadow.setOffsetY(5.0);
        shadow.setColor(Color.color(0.4, 0.5, 0.5));
        successBox.setEffect(shadow);

        StackPane root = new StackPane(successBox);
        root.setStyle("-fx-background-image: url('file:C:/Users/seang/OneDrive/Desktop/rupp logo.png'); " +
                "-fx-background-size: cover; " +
                "-fx-background-position: center center; " +
                "-fx-background-repeat: no-repeat;");

        Scene scene = new Scene(root);
        primaryStage.setScene(scene);
        primaryStage.setFullScreen(true);

        // Redirect to login page after a delay
        PauseTransition delay = new PauseTransition(Duration.seconds(5)); // 5 seconds delay
        delay.setOnFinished(event -> {
            LoginPage loginPage = new LoginPage();
            try {
                loginPage.start(primaryStage);
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });
        delay.play();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
