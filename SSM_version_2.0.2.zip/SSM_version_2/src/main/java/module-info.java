module com.example.ssm_version_2 {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;
    requires java.desktop;
    requires mssql.jdbc;
    requires org.apache.pdfbox;


    opens com.example.ssm_version_2 to javafx.fxml;
    exports com.example.ssm_version_2;
}